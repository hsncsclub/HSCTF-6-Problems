Written by: Disha
Name Credits: Shray

# A Lost Cause

Pirate Keith loves cryptography and has protected his treasure with a very annoying caesar shift. He has witten “CGULKVIPFRGDOOCSYTHPPKMPAOBXE” on his treasure chest and has left a piece of paper with the following message: “every subsequent letter is shifted one more than the previous.” Knowing this, can you unlock Pirate Keith’s treasure chest.

#Format

Remember to use the flag format and keep your answer in upper case.